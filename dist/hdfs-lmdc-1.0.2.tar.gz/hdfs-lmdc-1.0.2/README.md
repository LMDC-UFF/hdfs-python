# hdfs-python
Esta biblioteca tem como objetivo generalizar funções da integração entre HDFS e Python utilizando HDFS3


## Como usar localmente

Para utilizar esta biblioteca localmente, é necessário cloná-la para o diretório onde se encontra o arquivo no qual você deseja importar a mesma. Isto fará com que a biblioteca esteja somente disponível para tal diretório. 

## Como usar globalmente

Utilizar com PyPip.
